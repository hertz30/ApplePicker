# Emscripten Wwise Unity Build module
import BuildUtil
import platform
import os
from os import path
from BuildWwiseUnityIntegration import PlatformBuilder
from GenerateApiBinding import GccSwigCommand
from PrepareSwigInput import SwigPlatformHandlerPOSIX, SwigApiHeaderBlobber

class EmscriptenBuilder(PlatformBuilder):
	def __init__(self, platformName, arches, configs, generateSwig, generatePremake):
		PlatformBuilder.__init__(self, platformName, arches, configs, generateSwig, generatePremake)
		self.compiler = 'make'
		self.solution = 'AkSoundEngineEmscripten.make'

	def _CreateCommands(self, arch=None, config='Profile'):
		configString = 'config=' + config.lower()
		
		pathMan = BuildUtil.PathManager(self.platformName)
		slnDir = pathMan.Paths['Src_Platform']
		slnPath = path.join(slnDir, self.solution)
		execPath = path.join(slnDir, 'EmscriptenExec.bat')
		cmd = [execPath, 'emmake', self.compiler, '-C', slnDir, '-f', slnPath, configString]
		return [cmd]
		
class EmscriptenSwigCommand(GccSwigCommand):
	def __init__(self, pathMan):
		GccSwigCommand.__init__(self, pathMan)
		self.compilerDefines += ['-D__EMSCRIPTEN__']
		self.platformDefines += ['-DAK_EMSCRIPTEN']
		self.dllName = ['-dllimport', '__Internal']
	
class SwigApiHeaderBlobberEmscripten(SwigApiHeaderBlobber):
	def __init__(self, pathMan):
		SwigApiHeaderBlobber.__init__(self, pathMan)

		self.inputHeaders.append(path.normpath(path.join(self.SdkIncludeDir, 'AK/SoundEngine/Platforms/Emscripten/AkEmscriptenSoundEngine.h')))

class SwigPlatformHandlerEmscripten(SwigPlatformHandlerPOSIX):
	def __init__(self, pathMan):
		SwigPlatformHandlerPOSIX.__init__(self, pathMan)
		ThreadPropertyHeader = 'AK/Tools/Emscripten/AkPlatformFuncs.h'

def Init(argv=None):
	BuildUtil.BankPlatforms['Emscripten'] = 'Web'
	BuildUtil.PremakeParameters['Emscripten'] = { 'os': 'emscripten', 'generator': 'gmake' }
	BuildUtil.PlatformSwitches['Emscripten'] = '#if UNITY_WEBGL && ! UNITY_EDITOR'
	BuildUtil.SupportedPlatforms['Windows'].append('Emscripten')

def CreatePlatformBuilder(platformName, arches, configs, generateSwig, generatePremake):
	return EmscriptenBuilder(platformName, arches, configs, generateSwig, generatePremake)

def CreateSwigCommand(pathMan, arch):
	return EmscriptenSwigCommand(pathMan)

def CreateSwigPlatformHandler(pathMan):
	return SwigPlatformHandlerEmscripten(pathMan)

def CreateSwigApiHeaderBlobber(pathMan):
	return SwigApiHeaderBlobberEmscripten(pathMan)

if __name__ == '__main__':
	pass
